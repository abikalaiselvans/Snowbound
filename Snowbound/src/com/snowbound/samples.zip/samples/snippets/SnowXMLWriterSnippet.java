package com.snowbound.samples.snippets;

class getAnnotationBytes	{
/*
byte [] getAnnotationBytes(SnowAnn annotation)
{

    int acutalByteCount = 0;
    int initialArraySize = 50000;
    byte[] byteAnnOut = new byte[initialArraySize];

    SnowXMLWriter xmlWriter = null;

    try
    {
        xmlWriter = annotation.SANN_write_ann_xml_document(xmlwriter);
        actualByteCount = annotation.SANN_write_ann_xml(byteAnnOut, xmlwriter);
    }
    catch (ArrayIndexOutOfBoundsException aoobe)
    {
        // do something here
    }
    catch (IOException e)
    {
        // do something here
    }

    return byteAnnOut;
}
*/
}



